

"""
## Installation
Run the following to install:

'''python
pip install hellopython
"""

## Usage
'''Python
from hellodoodle import say_hello

# Generate "Hello, world!"
say_hello()

# Generate "Hello, Everybody!"
say_hello("Everybody")